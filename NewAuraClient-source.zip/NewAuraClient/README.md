# NewAuraClient starter

Target: Minecraft 1.21.11 / Fabric / Java 21.

This ZIP contains the initial project skeleton, module registry, starter module classes, and a properties-based config for Crystal Aura settings.

Important: the modules are currently scaffolding only; they do not yet implement in-game actions or a ClickGUI. No compiled JAR is included. Build with `gradle build` using Java 21 and Gradle 8.14. GitHub Actions is configured to build and upload the JAR artifact when pushed to `main` or run manually.
