package dev.newaura.client.module;

import dev.newaura.client.module.combat.*;
import dev.newaura.client.module.movement.*;
import java.util.*;

public final class ModuleManager {
    private final List<Module> modules = new ArrayList<>();
    public ModuleManager() {
        register(new CrystalAura());
        register(new AttackAura());
        register(new KillAura());
        register(new ElytraHelper());
        register(new ElytraTarget());
    }
    public void register(Module module) { modules.add(module); }
    public List<Module> getModules() { return Collections.unmodifiableList(modules); }
    public Module getModule(String name) {
        return modules.stream().filter(m -> m.getName().equalsIgnoreCase(name)).findFirst().orElse(null);
    }
    public void tick() {
        for (Module module : modules) if (module.isEnabled()) module.onTick();
    }
}
