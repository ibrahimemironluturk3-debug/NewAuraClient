package dev.newaura.client.module.combat;
import dev.newaura.client.module.*;
public final class KillAura extends Module {
    public double range = 4.0;
    public int delayMs = 500;
    public KillAura() { super("KillAura", ModuleCategory.COMBAT); }
}
