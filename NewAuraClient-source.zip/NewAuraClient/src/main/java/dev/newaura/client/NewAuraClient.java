package dev.newaura.client;

import dev.newaura.client.config.ClientConfig;
import dev.newaura.client.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;

public final class NewAuraClient implements ClientModInitializer {
    public static ModuleManager MODULES;
    public static ClientConfig CONFIG;

    @Override
    public void onInitializeClient() {
        CONFIG = new ClientConfig();
        MODULES = new ModuleManager();
        CONFIG.load(MODULES);
        System.out.println("[NewAuraClient] Loaded " + MODULES.getModules().size() + " modules.");
    }
}
