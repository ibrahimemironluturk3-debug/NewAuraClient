package dev.newaura.client.config;

import dev.newaura.client.module.*;
import dev.newaura.client.module.combat.CrystalAura;
import java.io.*;
import java.nio.file.*;
import java.util.Properties;

public final class ClientConfig {
    private final Path path = Path.of("config", "newauraclient.properties");

    public void save(ModuleManager manager) {
        Properties p = new Properties();
        for (Module m : manager.getModules())
            p.setProperty("module." + m.getName() + ".enabled", Boolean.toString(m.isEnabled()));
        Module m = manager.getModule("Crystal Aura");
        if (m instanceof CrystalAura c) {
            p.setProperty("crystal.placeRange", Double.toString(c.placeRange));
            p.setProperty("crystal.breakRange", Double.toString(c.breakRange));
            p.setProperty("crystal.minDamage", Double.toString(c.minDamage));
            p.setProperty("crystal.maxSelfDamage", Double.toString(c.maxSelfDamage));
            p.setProperty("crystal.placeDelayMs", Integer.toString(c.placeDelayMs));
            p.setProperty("crystal.breakDelayMs", Integer.toString(c.breakDelayMs));
            p.setProperty("crystal.autoSwitch", Boolean.toString(c.autoSwitch));
            p.setProperty("crystal.antiSuicide", Boolean.toString(c.antiSuicide));
            p.setProperty("crystal.wallCheck", Boolean.toString(c.wallCheck));
        }
        try {
            Files.createDirectories(path.getParent());
            try (OutputStream out = Files.newOutputStream(path)) { p.store(out, "NewAuraClient"); }
        } catch (IOException e) { System.err.println("Config save failed: " + e.getMessage()); }
    }

    public void load(ModuleManager manager) {
        if (!Files.exists(path)) return;
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(path)) {
            p.load(in);
            for (Module m : manager.getModules())
                m.setEnabled(Boolean.parseBoolean(p.getProperty("module." + m.getName() + ".enabled", "false")));
            Module m = manager.getModule("Crystal Aura");
            if (m instanceof CrystalAura c) {
                c.placeRange = d(p, "crystal.placeRange", c.placeRange);
                c.breakRange = d(p, "crystal.breakRange", c.breakRange);
                c.minDamage = d(p, "crystal.minDamage", c.minDamage);
                c.maxSelfDamage = d(p, "crystal.maxSelfDamage", c.maxSelfDamage);
                c.placeDelayMs = i(p, "crystal.placeDelayMs", c.placeDelayMs);
                c.breakDelayMs = i(p, "crystal.breakDelayMs", c.breakDelayMs);
                c.autoSwitch = b(p, "crystal.autoSwitch", c.autoSwitch);
                c.antiSuicide = b(p, "crystal.antiSuicide", c.antiSuicide);
                c.wallCheck = b(p, "crystal.wallCheck", c.wallCheck);
            }
        } catch (IOException e) { System.err.println("Config load failed: " + e.getMessage()); }
    }
    private static double d(Properties p, String k, double v) {
        try { return Double.parseDouble(p.getProperty(k)); } catch (Exception e) { return v; }
    }
    private static int i(Properties p, String k, int v) {
        try { return Integer.parseInt(p.getProperty(k)); } catch (Exception e) { return v; }
    }
    private static boolean b(Properties p, String k, boolean v) {
        return Boolean.parseBoolean(p.getProperty(k, Boolean.toString(v)));
    }
}
