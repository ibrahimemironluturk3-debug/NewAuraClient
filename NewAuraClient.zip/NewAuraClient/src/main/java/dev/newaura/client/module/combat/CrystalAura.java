package dev.newaura.client.module.combat;

import dev.newaura.client.module.Module;
import dev.newaura.client.module.ModuleCategory;

public final class CrystalAura extends Module {
    public double placeRange = 4.5, breakRange = 5.0, minDamage = 4.0, maxSelfDamage = 6.0;
    public int placeDelayMs = 100, breakDelayMs = 50;
    public boolean autoSwitch = true, antiSuicide = true, wallCheck = true;
    public CrystalAura() { super("Crystal Aura", ModuleCategory.COMBAT); }
}
