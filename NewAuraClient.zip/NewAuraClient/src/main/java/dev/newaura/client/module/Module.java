package dev.newaura.client.module;

public abstract class Module {
    private final String name;
    private final ModuleCategory category;
    private boolean enabled;

    protected Module(String name, ModuleCategory category) {
        this.name = name;
        this.category = category;
    }
    public final String getName() { return name; }
    public final ModuleCategory getCategory() { return category; }
    public final boolean isEnabled() { return enabled; }
    public final void setEnabled(boolean value) {
        if (enabled == value) return;
        enabled = value;
        if (value) onEnable(); else onDisable();
    }
    public final void toggle() { setEnabled(!enabled); }
    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
}
