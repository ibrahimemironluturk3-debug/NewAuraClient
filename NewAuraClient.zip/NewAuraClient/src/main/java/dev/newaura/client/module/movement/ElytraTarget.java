package dev.newaura.client.module.movement;
import dev.newaura.client.module.Module;
import dev.newaura.client.module.ModuleCategory;
public final class ElytraTarget extends Module {
    public double range = 30.0;
    public ElytraTarget() { super("Elytra Target", ModuleCategory.MOVEMENT); }
}
