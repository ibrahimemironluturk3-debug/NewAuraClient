package dev.newaura.client.module;

import dev.newaura.client.module.combat.CrystalAura;
import dev.newaura.client.module.combat.AttackAura;
import dev.newaura.client.module.combat.KillAura;
import dev.newaura.client.module.movement.ElytraHelper;
import dev.newaura.client.module.movement.ElytraTarget;
import java.util.*;

public final class ModuleManager {
    private final List<dev.newaura.client.module.Module> modules = new ArrayList<>();
    public ModuleManager() {
        register(new CrystalAura());
        register(new AttackAura());
        register(new KillAura());
        register(new ElytraHelper());
        register(new ElytraTarget());
    }
    public void register(dev.newaura.client.module.Module module) { modules.add(module); }
    public List<dev.newaura.client.module.Module> getModules() { return Collections.unmodifiableList(modules); }
    public dev.newaura.client.module.Module getModule(String name) {
        return modules.stream().filter(m -> m.getName().equalsIgnoreCase(name)).findFirst().orElse(null);
    }
    public void tick() {
        for (dev.newaura.client.module.Module module : modules) if (module.isEnabled()) module.onTick();
    }
}
