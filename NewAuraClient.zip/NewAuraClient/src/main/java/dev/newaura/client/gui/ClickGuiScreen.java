package dev.newaura.client.gui;

import dev.newaura.client.NewAuraClient;
import dev.newaura.client.module.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class ClickGuiScreen extends Screen {

    public ClickGuiScreen() {
        super(Text.literal("NewAuraClient"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);

        int centerX = this.width / 2;
        int centerY = this.height / 2;

        context.fill(centerX - 110, centerY - 100,
                centerX + 110, centerY + 100, 0xE91A1A24);

        context.fill(centerX - 110, centerY - 100,
                centerX + 110, centerY - 75, 0xFF673AB7);

        context.drawCenteredTextWithShadow(
                textRenderer, "NewAuraClient",
                centerX, centerY - 92, 0xFFFFFF);

        int y = centerY - 60;

        for (Module module : NewAuraClient.MODULES.getModules()) {
            context.drawTextWithShadow(
                    textRenderer,
                    module.getName(),
                    centerX - 90,
                    y,
                    0xFFFFFF
            );
            y += 20;
        }

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}