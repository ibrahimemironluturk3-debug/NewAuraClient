package dev.newaura.client;

import dev.newaura.client.config.ClientConfig;
import dev.newaura.client.module.ModuleManager;
import dev.newaura.client.gui.ClickGuiScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class NewAuraClient implements ClientModInitializer {
    public static ModuleManager MODULES;
    public static ClientConfig CONFIG;

    private static KeyBinding openGui;

    @Override
    public void onInitializeClient() {
        CONFIG = new ClientConfig();
        MODULES = new ModuleManager();
        CONFIG.load(MODULES);

        openGui = KeyBindingHelper.registerKeyBinding(
            new KeyBinding(
                "key.newaura.clickgui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.MISC
            )
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGui.wasPressed()) {
                client.setScreen(new ClickGuiScreen());
            }
        });

        System.out.println("[NewAuraClient] Loaded " + MODULES.getModules().size() + " modules.");
    }
}
