package dev.newaura.client.module.movement;
import dev.newaura.client.module.Module;
import dev.newaura.client.module.ModuleCategory;
public final class ElytraHelper extends Module {
    public boolean showDirection = true, showSpeed = true;
    public ElytraHelper() { super("Elytra Helper", ModuleCategory.MOVEMENT); }
}
