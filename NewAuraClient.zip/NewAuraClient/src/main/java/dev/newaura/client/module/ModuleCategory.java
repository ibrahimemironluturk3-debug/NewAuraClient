package dev.newaura.client.module;
public enum ModuleCategory { COMBAT, MOVEMENT, PLAYER, RENDER, WORLD, HUD }
