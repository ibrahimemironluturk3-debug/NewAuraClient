# NewAuraClient starter

Target: Minecraft 1.21.11 / Fabric / Java 21.

This ZIP contains the initial project skeleton, module registry, starter module classes, and a Properties-based config for Crystal Aura settings. Java module imports have been made explicit to avoid the `java.lang.Module` name collision.

Important: the modules are scaffolding only; they do not yet implement in-game actions or a ClickGUI. Build with Java 21 and Gradle 9.2.1. GitHub Actions can build and upload the JAR artifact.
